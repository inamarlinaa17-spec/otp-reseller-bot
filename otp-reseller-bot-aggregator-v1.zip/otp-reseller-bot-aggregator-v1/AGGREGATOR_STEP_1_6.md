# Price Aggregator — Step 1-6

Perubahan ini menambahkan mode **Price Aggregator — 5SIM + SMSPool** tanpa menghapus Server 1 dan Server 2 lama.

## Alur
1. Menu Order OTP
2. Pilih `🔥 Price Aggregator — 5SIM + SMSPool`
3. Pilih layanan
4. Pilih negara
5. Bot mengambil semua quote aktif dari 5SIM dan SMSPool
6. Quote diurutkan dari harga jual termurah
7. User memilih quote tertentu
8. Bot menyimpan `quote_id` di PostgreSQL lalu membeli dari provider yang dipilih

## File baru
- `aggregator.py` — adapter/normalizer 5SIM + SMSPool

## Perubahan database
Tabel `otp_quotes` dibuat otomatis oleh `init_database()`. Tidak perlu SQL manual jika bot melakukan startup normal.

## Railway
Tidak ada environment variable baru pada tahap ini. Gunakan API key 5SIM dan SMSPool yang sudah ada.

## Catatan harga
Aggregator tidak mengubah harga modal provider. Harga yang tampil tetap dihitung menggunakan `hitung_harga_jual()` yang sudah dipakai bot. Jika margin bot masih lebih tinggi daripada MOCHI, angka jual tetap bisa lebih mahal walaupun provider yang sama digunakan.
